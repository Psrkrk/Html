// objects in javascript
//*************************part 1 *********************************** */
// object.creat // construct method thrugh object creation
// const user = {}  // object creation syntax



//object literal
// const user = {
//     name: "pankaj",
//     Symbol1: "key1",
//     age: 21,
//     locaton: "Agra",
//     email: "pankaj@google.com",
//     isloggedin: false,
//     lastlogindays: ["monday", "sunday"]

// }

// console.log(user.age)// acess object synntax
// console.log(user.email)// acess object synntax


// Symbol creation syntax
// const Symbol1 = Symbol("key1")
// console.log(user.Symbol1)

// user.greeting = function() { // function dclaretion 
//     console.log("hello js user")
// }
// console.log(user.greeting)




//***********************part 2 objects***************************** */


// const user = new Object() // singleton object
// const tinderuser = {} //nonsingle ton object

// console.log(tinderuser)
// console.log(user)

// const User = {}

// User.Id = "1234"
// User.name = "same altman"
// User.isloggedIn = false

// console.log(User)


// const regularuser = {
//     email: "pankaj@google.com",
//     fullname: {
//         userfullname: {
//             firstname: "pankaj",
//             lastname: "suman"
//         }
//     }
// }


//console.log(regularuser.fullname.userfullname.firstname.lastname);

// const obj1 = { 1: "a", 2: "b" }
// const obj2 = { 3: "c", 4: "d" }

// const obj3 = Object.assign({}, obj1, obj2) //combine two object 
// console.log(obj3); 

// const obj3 = {...obj1, ...obj2 } // spread two object
// console.log(obj3)

// const users = [ //array of objects
//     {
//         id: 1,
//         email: "pankaj@gmail.com"
//     },
//     {
//         id: 1,
//         email: "pankaj@gmail.com"
//     },
//     {
//         id: 1,
//         email: "pankaj@gmail.com"
//     }
// ]

// users[1].email;