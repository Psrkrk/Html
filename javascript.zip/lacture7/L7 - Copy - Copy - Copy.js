//stack and heap memory in javascript

//*********************** Memory ******************************

//Stack (primitive), Heap (non primitive)

// let myyoutubename = "funchallange"

// let anothername = myyoutubename
// console.log(anothername) // myyoutubename

// anothername = "chai or code"
// console.log(anothername)
// console.log(myyoutuben ame)

let userone = {
    Email: "pankaj@gmail.com",
    upi: "user@ybl"
}
let userTwo = userone
userTwo.Email = "pankaj@gmail.com"
console.log(userone.Email)
console.log(userTwo.Email)