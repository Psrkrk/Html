// arrays
//*********************************************************** */

const array1 = [0, 1, 2, 3, 5] //arrays contain diffrent type of data
const array2 = ["pankaj", "deepak"]

// const array3 = new Array(1, 2, 3, 4, 5, )
// console.log(array1[1])

//arrrays method
// array1.push(6)
// console.log(array1)//push used for add element arrays
// array1.pop()
// console.log(array1)// pop used remove last of arrays
array1.unshift(2)
console.log(array1) //unshipt use for add element in begining in the arrays