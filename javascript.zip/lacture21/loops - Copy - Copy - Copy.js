//************** loops(itrations) ************************* */ */

// for (var i = 0; i <= 10; i++) {
//     const element = i;


//     if (element == 5) {
//         console.log("5 is best number")
//     }
//     console.log(element)
// }

// for (let i = 0; i <= 10; i++) {
//     console.log("outer lops", i)
//     for (let j = 0; j <= 10; j++) {
// console.log("inner loops", i)
//         console.log(i + '*' + j + ' = ' + i * j)

//     }
// }

// let myarr = ["pankaj", "deepak", "aditya"]

// for (let index = 0; index < myarr.length; index++) {
//     const element = myarr[index];
//     console.log(element)

// }

// condition in loops //break and continue

// for (let index = 1; index <= 20; index++) {
//     if (index == 5) {
//         console.log("detect five")
//         break
//     }
//     console.log("value ", index)
// }

// for (let index = 1; index <= 20; index++) {
//     if (index == 5) {
//         console.log("detect five")
//         continue
//     }
//     console.log("value ", index)


// }