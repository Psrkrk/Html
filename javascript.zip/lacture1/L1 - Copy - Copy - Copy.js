const accountId = 144553
let accountEmail = "pankajsuman@gamil.com"
var accountPassword = "12345"
accountCity = "agra" // not allowed this type
let accountState;

// accountId = 2 // not allowed

//semicolon not complesory
//in the javascript are two types of  variable 1 var 2 let
// prefer not use var becouse of issue in block scop and functional scop
// if forgot variable decleration then javascript bydefault manage memory
accountEmail = "pankaj@gamil.com"
accountPassword = "345"
accountCity = "agra"

console.log(accountId);

console.table([accountId, accountEmail, accountPassword, accountCity, accountState])