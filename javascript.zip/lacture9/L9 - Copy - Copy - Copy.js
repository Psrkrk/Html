//number

// *******************************************************
//one way to declare string


// const score = 400
// console.log(score) //400
//second  way to declare string


// const balance = new Number(100)
// console.log(balance); //[Number: 100]

//NOTE - second way into show data with data type


// console.log(balance.toString().length) //3
// console.log(balance.toFixed(2)) //100.00

// const secondnumber = 23.5678
// console.log(secondnumber.toPrecision(3)) //23.6


// const number = 1000000
// console.log(number.toLocaleString()) //10,00,00
// console.log(number.toLocaleString('en-IN')) //1,000,000


console.log(Math) //math is a object

// console.log(Math.abs(-4)) //abs convert only negetive value into positive not vise warsa


// console.log(Math.round(4.3)) //4
// console.log(Math.round(4.6)) //5
// console.log(Math.ceil(4.2)) //5
// console.log(Math.floor(4.2)) //44
// console.log(Math.sqrt(2))

const min = 10
const max = 20
console.log(Math.random() * (max - min + 1))