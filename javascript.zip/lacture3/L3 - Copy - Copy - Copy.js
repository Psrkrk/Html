// let score = "33abc" //string
// let score = 33  //number
// let score = null //0
// let score = undefined //undefined
// let score = true //1


// we will check data types
// let isLoggedIn = 1
// let booleanIsLoggedIn = Boolean(isLoggedIn)
// console.log(booleanIsLoggedIn)

let someNumber = 33
let stringNumber = String(someNumber)
console.log(stringNumber)
console.log(typeof stringNumber)


// 1 => true;
// 0 => false;
// "" => false;
// "pankaj" => true;


// console.log(typeof score)
// console.log(typeof(score))

// let valueInNumber = Number(score)
// console.log(typeof valueInNumber) //number
// console.log(valueInNumber)

// "33" => 33
// "33ab" => NaN(number)