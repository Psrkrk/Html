//******************* //object de structure and jSON API*************/

const course = {
        coursename: "js hindi",
        price: 8000,
        courseteacher: "pankaj"

    }
    // 

// const { courseteacher } = course
// console.log(courseteacher); 
//NOTE : sometime semicolon arecomplesory

//************************JSON format*********************** */
// {
//     name: "panakaj",
//     coursename: "js,"
//     price :"free",

// }


//*********second formate of api***************** */
[
    {},
    {},
    {}
]