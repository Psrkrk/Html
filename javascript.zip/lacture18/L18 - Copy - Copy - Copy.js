//*********immediately invoked function expression (IIFE)****************** */

// (function chai() { //named IIFE
//     console.log('DB CONNECTED');
// })();



//NOTE global scope ke variable uske problem ko dur karne ke liye hum (IIFE) ka use karte hai
//NOTE jo functions immediately execute ho jaye that called (IIFE)

// ISSE arrrow function me kaise likhenge


// ((name) => {  //unamed IFFE
//     console.log(name);
// })('pankaj')


//************how does javascript execute code + call stack**************** */

//global execution context
//function execution context
//eval execution context