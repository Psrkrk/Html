// oprations in java script

// let value = 3
// let negValue = -value //-3
// console.log(negValue)

//  arithmetic oprations
// console.log(2 + 2) //4
// console.log(2 - 2) //0
// console.log(2 * 2) //4
// console.log(2 ** 2) // 4
// console.log(2 / 2) // 1
// console.log(2 % 2) //0

// let str1 = "hello"
// let str2 = "hello"

// let str3 = str1 + str2
// console.log(str3) //hello hello

// console.log("1" + 2) //12
// console.log(1 + "2") //12
// console.log("1" + 2 + 2) //122
// console.log(1 + 2 + "2")//32


//tricky conversion

// console.log(true) //true
// console.log(+true) //1
// console.log(true+) // not valid
// console.log(+"") //0

// let num1, num2, num3
// num = num2 = num3 = 2 + 2

// let gameCounter = 100
// gameCounter++
// console.log(gameCounter) //101