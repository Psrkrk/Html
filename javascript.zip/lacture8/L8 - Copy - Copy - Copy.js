// string in javascript


// const name = "pankaj"
// const lecture = 50
// console.log(name + lecture) //pankaj50

// console.log('hello my nmae is ${name} and my lacture is${lacture}')

// other way to declare string
const gamename = new String('pankaj-vi')
    // console.log(gamename[0]) //0

// console.log(gamename.__proto__)


// console.log(gamename.length)//9
// console.log(gamename.toUpperCase())//PANKAJ VI
// console.log(gamename.charAt(7))//v
// console.log(gamename.indexOf('p'))//0

// const str1 = gamename.substring(0, 4)//substring method not contain negetive value 
// console.log(str1)//pank

// const str2 = gamename.slice(-8, 4)//slice method contain negtetive value
// console.log(str2)//ank


// const str3 = "  pankaj "
// console.log(str3)
// console.log(str3.trim()) // space remove 

// const url = "https://pankaj.com/pankaj%20suman"
// url.replace('20%', '-')
// console.log(url.includes('pankaj'));


console.log(gamename.split())