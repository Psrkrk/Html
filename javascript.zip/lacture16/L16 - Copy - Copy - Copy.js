//*************global and local scope ***********************8 */


// let a = 10 // globbaly scope
// const b = 20
// var c = 30


// if (true) { // block scope 
//     let a = 10
//     const b = 20
//     var c = 30
//     console.log(a)
//     console.log(a)
//     console.log(a)



// }
// console.log(a)
// console.log(b)
// console.log(c)

//NOTE block scope pahle print hota jabki global scope baad me



//*******************scope level and mini hoisting************************ */


// function one(){
//     const username = "pankaj"
//     function two(){
//         const website ="youtube"
//         console.log(username)

//     }
//     console.log(website)

//     two()
// }

// one()
//NOTE childs class can acess perent class but perent class cannot acess child claas

// if (true) {
//     const username = "pankaj"
//     if (username === "pankaj") {
//         const website = "youtube"
//         console.log(username + website)

// console.log(website) // not print becouse only acessable block

// }
// console.log(username)//not print becose out of semicolcon



//++++++++++++interesting point++++++++++++++++++++

// addone(5) // not errror

// function addone(num) { // first function ceation syntax
//     return num + 1

// }

//  addtwo(5) // error becouse //NOTE this mini hoisting concept
// const addtwo = function(num) { // second function ceation syntax
//         return num + 2

//     }