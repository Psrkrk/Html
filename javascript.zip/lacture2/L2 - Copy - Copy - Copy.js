//data types in javascript



"use strict"; //treat all js code as newer version

// alart("3+3") // we are using nodeJs not browser

let name = "panakj"
let age = 20
let isLoggedIn = false

// primitive data types :
// bigint
// string
//  number
//  boolean
//null // null is a object
//undefined
//symbol= unique

//object