// arrrays part 2
//************************************************ */

// const heros = ["spiderman", "pankaj", "deepak", "rahul"]

// const family = ["ravi", "mummy", "papa"]

// heros.push(family)
// console.log(heros) // this is not valid syntax for arrays add

// heros.concat(family)
// console.log(heros); // not valid syntax for arrays adding

// const my_heros = heros.concat(family)
// console.log(my_heros) //valid syntax for arrays adding

// const my_heros = [...heros, ...family]
// console.log(my_heros); // same like concate works

// const array2 = [1, 2, 3[4, 5, 6], 7, [6, 7, [4, 5]]]
// const real_array2 = array2.flat[Infinity]
// console.log(array2);



// console.log(Array.isArray("pankaj")) //false
// console.log(Array.from("pankaj"))//convert any syntax in arryas form
// console.log(Array.from({ name: "hetsh" })) //important5 case


let score1 = 100
let score2 = 200
let score3 = 300

console.log(Array.of(score1, score2, score3)) //convert into arrrys