//****************        control flow     ******************************** */


// if statement 
// const userlogged = true
// const temprature = 40
// if (temprature < 50) { //valid 

//     console.log("less than 50")
// }
// console.log("temprature is grater than 50"); // ye print hoga hi hoga becouse iska if 
// statement se khuch lena dena nahi h
// if (2==2){ // this is also valid  
// }
// if (userlogged){


// }

//NOTE - oprators
// <,
// >,
// <=,
// >=,
// =   //oprator assign
// == // comprison and eqality check oprator
// === //type check comprator 
//  !=  not qual oprator

// NOTE example of ===

// if (2 == "2") {   
//     console.log("execut code") // print 
// NOTE becouse two equal not check data so print

// if (2 === "2") {
//     console.log("execut code") // not print 
//NOTE becouse data types is not same if data type same then print 

// }
// console.log("hi pankaj") // print


//NOTE  (===) ye data ka type check karta hai tabhi loop ke andar jata hai
// in the above example number cannot string equal(2 ==="2")


// const score = 200

// if (score > 100) {
// var power = "fly"  //invalid
// let power = "fly"  //invalid
//     const power = "fly" //valid 
//     console.log("user power :", (power))
// }
// console.log("user power :", (power))


//NOTE var variable isliye invalid kyoki vah loop ke bahar bhi acessable hota hai
//jabki hona nahi chahhiye //ye globlly acessble hota hai


// shorthand notation

// const balance = 1000

// if (balance > 500) console.log("execute"), //this is also valid syntax but readable syntax
//     console.log("execute 2") //this isb also valid syntax but readable syntax


// const balance = 1000

// if (balance > 500) {
//     console.log("yes") //yes
// } else if (balance < 750) {
//     console.log("NO")
// } else if (balance < 900) {
//     console.log("No")
// } else {
//     console.log("less than 1200");
// }

// const userloggedIn = true
// const debitcard = false
// const loggedfromgoogle = false
// const loggedinfromemails = true

// if (userloggedIn && debitcard) {
//     console.log("you can buy courses")
// }
// if (loggedfromgoogle || loggedinfromemails) {
//     console.log("you can buy courses")
// }




// Nullish coalescing oprator. null/undefined

// let val1;
// val1 = 5 ? ? 10
// console.log(val1) //5
// val1 = null ? ? 10
// console.log(val1) //10
//   val1 = undefined ? ? 10
// console.log(val1) // 15
// val1 = undefined ? ? 10 ?? 15 
// console.log(val1) // 10

//NOTE (??) this is called safty check oprator

// Turniary Oprator (if else of small part)

// condition ? true :false
// e.g

// const iceprice = 100
// iceprice >= 80 ? ?
//     console.log("less than 80")
//     console.log("more than 80")