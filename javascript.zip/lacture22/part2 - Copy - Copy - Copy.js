// ****************** filter map and reducing *******************

// const coding = ['js', 'ruby', 'java', 'python', 'cpp']

// const values = coding.forEach((item) => {
//     console.log(item)
//     return item

// })
// console.log(values);
// *********** basis of  filter **********
// first method
// const myarr = [1, 2, 3, 4, 5, , 6, 7, 8, 9, 10]
// const newmyarr = myarr.filter((item) => item > 4)
// console.log(newmyarr)

// second method


// const myarr = [1, 2, 3, 4, 5, , 6, 7, 8, 9, 10]
// const newmyarr = myarr.filter((item) => {
//     return item > 4 // in case return is complesory
// })
// console.log(newmyarr)

// ********************* same works to for each loop ********!SECTION
// const myarr = [1, 2, 3, 4, 5, 6, 7, 8, 9]

// myarr.forEach((item) => {
//         if (item > 4)
//             myarr.push(item)
//     }

// )
// console.log(myarr);

// ******** map **********
// const myarr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

//  const myarr1 = myarr.map((item) => item + 10)
// const myarr1 = myarr.map((item) => item * 10).map((item) => item + 1)
//     .filter((item) => item > 40)
// console.log(myarr1)

// ************* reduce ******************!SECTION
// const myarr = [1, 2, 3]

// const myarr1 = myarr.reduce(function(acc, curvalue) {

//     return acc + curvalue
//     console.log(acc + curvalue)
// }, 0)
// console.log(myarr1)