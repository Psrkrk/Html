//*************** loops *************** */


//*********  while loops ************* */

// let index = 0
// while (index <= 10) {!
//     console.log("value is index of ", index)
//     index = index - 2
// }

// let arr = ["pankaj", "shivani", "dseepak"]

// while (arr <= arr.length) {
//     console.log(arr);
//     arr = arr + 1


// }

// ****************** Do while **************!SECTION

// let score = 11

// do {
//     console.log("score is", score)
//     score++
// }
// while (score <= 10) {

// }

// ********************** higher order array loops ************!SECTION

// ********* for of loop ***************!SECTION

// const arr = [1, 2, 3, 4, 5]
// for (const num of arr) {
//     console.log(num)

// }
// const greeting = "hellow worls!"
// for (const greet of greeting) {
//     console.log(greet)

// }


// **************** for of loops for Maps ********************!SECTION
// const map = new Map()
// map.set('IN', 'india')
// map.set('USA', 'unite state america')
// map.set('fr', 'france')
//  console.log(map);

//  NOTE -map are only contains unique value not duplicate value

// for (const [key, value] of map) {
//     console.log(key, ':-', value)


// }

// ************************** (for of loop) for objects *********

//first structure

// const myobject = {
//     'game': 'NFS',
//     'game2': 'spiderman'

// }

// for (const [key, value] of myobject) {
//     console.log(key, ':-', value)

// }

// NOTE this is not valid method for (for of loop) for object not works
// *********************** (for in loops) in object *************
// second structure

// const myobject = {
//     js: 'javascript',
//     cpp: 'c++',
//     rb: 'rubi',
//     swift: 'swift by'
// }

// for (const key in myobject) {
//     console.log(key)//for key print
// console.log(myobject[key])//value print
// }

// ****************** (for in loop) on array ***************

// const programming = ['js', 'rb', 'java', 'cpp', 'py']
// for (const key in programming) {
//     console.log(programming[key])
// }

// NOTE array of indexing is called key in (for in loop)


// ******************* for each loop  ******************!SECTION 

// const coding = ['js', 'rb', 'java', 'python', 'cpp']

// coding.forEach(function name(item) {
//     console.log(item)
// })
// coding.forEach((item) => {})//arrow function foreach loop


// function printMe(item) {
//     console.log(item);
// }
// coding.forEach(printMe)