//Date and time in java script 
//********************************************************** */
// let date = new Date()
// console.log(date) // 2024-01-28T04:18:47.483Z
// console.log(date.toString())
// console.log(date.toJSON())
// console.log(typeof date) //date is a object

// let specifidate = new Date(2023, 0, 23)
// console.log(specifidate.toDateString())

let timestamp = Date.now()
console.log(timestamp) //1706416241083 milisecond