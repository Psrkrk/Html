//*********************function in javascript************* */

// function name() {
//     console.log("h")
//     console.log("i")
//     console.log("t")
//     console.log("e")
//     console.log("s")
//     console.log("h")

// }

// name(); //execution syntax

// function addtwonumber(n1, n2) { //n1 ,n2 is parameter
//     console.log(n1 + n2);

// }


// function addtwonumber(n1, n2) { //n1 ,n2 is parameter
// let result = n1 + n2;
// return result

// return n1 + n2

// }
// addtwonumber(7, 8); // 7, 8 is argument


// const result = addtwonumber(3, 5) //8
// console.log("result", result);


// function userlogin() {
//     return '${username} just logged in'
// }

// console.log(userlogin("pankaj"))


//************************function part 02 ************************** */



// function calculateCartPrice(val1, val2, ...num1) {
//     return num1
// }
// console.log(calculateCartPrice(200, 400, 600, 800))

// const user = {
//     username: "pankaj",
//     price: 199
// }

// function handleobject(anyobject) {
//     console.log('username is  ${anyobject.user} and price is ${anyobject.price}')
// }
// handleobject(user)
// handleobject({
//     username: "bsame",
//     price: 399
// })

// const mynewarrays = [200, 400, 100, 600]

// function returnSecondValue(getarray) {
//     return getarray[1]

// }
// console.log(returnSecondValue(mynewarrays));