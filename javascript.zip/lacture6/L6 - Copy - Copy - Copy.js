//primitive data types

// string
// Number
// Boolean
// null
// undefined
// Symbol
// BigInt //big integer


//refrence or non primitive types
// Array
// object
// function

// const score = 100
// let scoreValue = 100.5

// const isLoggedIn = false
// const outsideTemp = null
// let userEmail;

// const id = Symbol('123')
// const anotherId = Symbol('123')
// console.log(id === anotherId)

// const heros = ["salman", "sahrukh","akshay"] //array

let myObj = { // object 
        name: "pankaj", //Note : object are contains every data type
        age: 30,
    }
    // function 


const myfunction = function() {}
console.log("hello javascript")