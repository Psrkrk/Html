 //************** this and arrow function************** */

 //  const user = {
 //          username: 'pankaj',
 //          price: 999,

 //          welcomeMassage: function() {
 //              console.log((this.username), "welocme to website");
 //              console.log(this)// empty object {}
 //          }

 //      }
 //  NOTE this keyboard ka use current context ko print karne ke liye use hota hai

 //   user.welcomeMassage()
 //   user.username = "sam altamn"
 //   user.welcomeMassage()

 //  function chai() {
 //      console.log(this)
 //      console.log(this.username) // not valid
 //  }
 //  chai()

 //NOTE function ke andar this work nahi karta object ke andar karta hai

 //  const chai = () => { //this is arraow functions
 //      let username = " hitesh"
 //      console.log(this.username) //undefined
 //      console.log(this) //{}


 //  }
 //  chai()


 // ***************** Arrow functions *************************** */

 //  const addtwo = (num1, num2) => {  // arrow function creation syntax 1
 //      return num1 + num2

 //  }
 //  console.log(addtwo(3, 4));//7

 // const addtwo = (num1, num2) => num1 + num2 // arrow function creation syntax 2

 // console.log(addtwo(3, 4));//7