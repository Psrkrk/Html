// ******************  switch case **************************!SECTION


// const month = 3

// switch (month) {
//     case 1:
//         console.log("january")
//         break;
//     case 2:
//         console.log("february")
//         break;
//     case 3:
//         console.log("march")
//         break;
//     case 4:
//         console.log("april")
//         break;
//     default:
//         console.log("does'nt exist")
// }

//NOTE agr hamara case match ho gaya or humne breck condition nahi di
//then uske aage ka sara code except default execute karta hai


//************** Assume case *************************** */  

// const useremail = "pankaj@gmail.com"

// if (useremail) {
//     console.log("got user email")
// } else {
//     console.log("dont have user email")
// }

// ***************  falsy values asssume ***************
// false,0,-0,bigint 0in,null,"",NaN
//************** truthy value assume  ************/
// falsy value ko chod kar baki sb truthy hoti h

//NOTE Some special case of truthy
// "0", 'false'," ",[],{},function{}{} becouse ye string ke andar hai